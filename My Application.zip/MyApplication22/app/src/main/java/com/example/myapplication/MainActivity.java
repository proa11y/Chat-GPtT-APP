package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ChatAdapter chatAdapter;
    private ArrayList<ChatMessage> chatMessages;
    EditText editText;
ImageView button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
editText = findViewById(R.id.send);
        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatMessages,this);
button = findViewById(R.id.button);

button.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String text = editText.getText().toString();
        sendUserMessage(text);
    }
});

    }

    private void sendUserMessage(String message) {
        ChatMessage userMessage = new ChatMessage("user", message);
        chatMessages.add(userMessage);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(chatAdapter);
        chatAdapter.notifyDataSetChanged();

        recyclerView.smoothScrollToPosition(chatMessages.size() - 1);
        apirequest(message);
    }

    private void processAssistantResponse(String response) {
        ChatMessage assistantMessage = new ChatMessage("assistant", response);
        chatMessages.add(assistantMessage);
        chatAdapter.notifyDataSetChanged();
        recyclerView.smoothScrollToPosition(chatMessages.size() - 1);
    }
    public void apirequest(String message){
        String apiKey = "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";

        String url = "https://api.openai.com/v1/completions";


// Create the request body
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("model", "text-davinci-003");
            jsonBody.put("prompt", message);
            jsonBody.put("max_tokens", 150);
        } catch (JSONException e) {
            e.printStackTrace();
        }

// Create the request
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                url,
                jsonBody,
                response -> {
                    // Handle the API response here
                    try {
                        String completion = response.getJSONArray("choices").getJSONObject(0).getString("text");
                        // Process the completion
                        Log.d("TAG", "onCreate: "+completion);
                        processAssistantResponse(completion
                        );
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    // Handle API error here
                    if (error.networkResponse != null) {
                        String errorMessage = new String(error.networkResponse.data);
                        Log.e("API Error", errorMessage);
                        processAssistantResponse(errorMessage);

                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", "Bearer " + apiKey);
                return headers;
            }
        };

// Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
    }
    }
